# @cntvos/icons

Íconos de Centavos como **datos neutros de plataforma**: nombres, paths SVG, el contrato de diseño y el mapeo de beneficios. No tiene React ni dependencias de runtime. Los componentes `<Icon>` de React Native y web (`@cntvos/ui-native`, `@cntvos/ui-web`) se alimentan de estos datos.

## Qué exporta

| Export | Qué es |
|---|---|
| `CATEGORY_ICON_NAMES`, `UI_ICON_NAMES`, `IconName` | Los 37 nombres, agrupados por rol (14 de categoría, 23 de UI). |
| `categoryIconName(key)` | Clave del catálogo (`personal_care`) → nombre del ícono (`category-personal-care`). |
| `GLYPHS` | `Record<IconName, string>`: el `d` de un único `<path>` por ícono. |
| `ICON_GRID`, `ICON_STROKE_WIDTH`, `ICON_VIEWBOX`, `ICON_STROKE_ATTRS` | El contrato: grilla 24, trazo 1.75, extremos y uniones redondeados, sin relleno. |
| `BENEFIT_ICON_BY_KEY`, `BENEFIT_FALLBACK_ICON`, `benefitIconName(key)` | Clave de beneficio Centavos+ → ícono, con `badge-plus` de respaldo. |
| `iconSvg(name, opts)` | String SVG autónomo (docs, correos, páginas renderizadas en servidor), o `null` si el nombre no existe. |

```ts
import { iconSvg, GLYPHS } from "@cntvos/icons";

iconSvg("tab-amigos");                      // decorativo: aria-hidden="true", stroke="currentColor"
iconSvg("badge-plus", { size: 32, title: "Centavos+" }); // role="img" + <title>
```

Los valores de atributos se escapan. `iconSvg` usa `currentColor` por defecto, así que el ícono toma el color del texto que lo rodea.

## Actualizar el arte

`src/glyphs.ts` es **generado**: no se edita a mano. Se regenera desde el `glyphs.generated.tsx` de la app:

```sh
cd packages/icons
bun scripts/import-glyphs.ts <ruta-a>/glyphs.generated.tsx
```

El script lee el `.tsx` como texto, aplica el renombre `category-personal_care` → `category-personal-care` y falla si alguna entrada no es exactamente un `<Path d="…" />`. Si el arte trae un nombre nuevo, hay que agregarlo también a `src/names.ts` (el test de cobertura lo exige). Para comprobar contra una versión más nueva de la app sin copiarla al fixture: `APP_GLYPHS_FILE=<ruta> bun test`.

## Pruebas

`bun run test` verifica que cada nombre tenga glifo y viceversa, que los `d` solo usen caracteres válidos de path, el mapeo de beneficios, los snapshots de `iconSvg` y la **fidelidad**: el importador, ejecutado sobre una copia literal del archivo de la app (v1.11.1, en `test/fixtures/`, con extensión `.txt` para que `tsc` no la compile), debe producir exactamente el `glyphs.ts` versionado.
